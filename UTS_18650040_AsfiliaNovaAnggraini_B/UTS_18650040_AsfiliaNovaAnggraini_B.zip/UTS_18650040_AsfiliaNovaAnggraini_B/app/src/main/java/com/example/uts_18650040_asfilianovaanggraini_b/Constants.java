package com.example.uts_18650040_asfilianovaanggraini_b;

public class Constants {
    public static final String URL= "http://asfilianova.000webhostapp.com/";
    public static final String ROOT_URL = URL+"crud_api/";
    public static final String URL_ADD = ROOT_URL+"add.php";
    public static final String URL_DELETE = ROOT_URL+"delete.php";
    public static final String URL_UPDATE = ROOT_URL+"update.php";
    public static final String URL_SELECT = ROOT_URL+"select.php";
    public static final String URL_SELECT_ID = ROOT_URL+"select_id.php";
}
